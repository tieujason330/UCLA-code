C.evalAST = function(ast) {
  throw new Error("You're supposed to write your own evaluator and hook it up to this method.");
};

