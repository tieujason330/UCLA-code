function match(value /* , pat1, fun1, pat2, fun2, ... */) {
  // ...
}

