Jason Tieu
304047667

Project 4

- The item result page should be viewed on a fully expanded browser.

- For item result page, Longitude and Latitude appear below Location 
and Country if they are specified

- for item result page, Buy Price appears in red if it is 
specified

- Looking up an invalid or empty Item ID would result in an 
item result page where all the fields are empty or null. 
Header will read "Item ID is not valid."

- Looking up an empty query should return a page that says 
"No results found for ""."

- Looking up a query <q> with no results should return a page 
that says "No results found for "<q>"." where <q> is the query.