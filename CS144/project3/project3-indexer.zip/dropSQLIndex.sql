-- Jason Tieu
-- 304047667

-- Drop TABLE
DROP TABLE IF EXISTS SpatialTable;

-- Drop INDEX
DROP INDEX sp_index ON SpatialTable;