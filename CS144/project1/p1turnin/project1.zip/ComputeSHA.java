import java.io.*;
import java.security.*;

public class ComputeSHA {

	public static void main(String args[]) throws Exception
	{
		if (args.length != 1)
		{
			throw new IllegalArgumentException();
		}
		
		byte[] arr;

		MessageDigest md = MessageDigest.getInstance("SHA-1");
		
		try 
		{	
			FileInputStream fileStream = new  FileInputStream(args[0]);

			int nRead;
			byte[] data = new byte[16384];

			while ((nRead = fileStream.read(data)) != -1) 
			{
				md.update(data, 0, nRead);
			}
		}
		catch(FileNotFoundException f)
		{
			System.out.println("No such file or directory");
			throw new FileNotFoundException();
		}
		
		//c.printSHA();
		arr = md.digest();
		String result = "";
		  for (int i=0; i < arr.length; i++) 
		  {
		    result +=
		          Integer.toString( ( arr[i] & 0xff ) + 0x100, 16).substring( 1 );
		  }
		  System.out.println(result);
	}
}