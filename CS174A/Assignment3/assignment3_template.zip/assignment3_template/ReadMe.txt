========================================================================
    template-rt: Template for ray tracer
========================================================================

Contents of the project:

- raytrace.cpp: main source file
- matm.h: modified mat.h from Edward Angel. Code to invert a matrix 
  was added there (function InvertMatrix).
- vecm.h: modified vec.h from Edward Angel.

You may modify raytrace.cpp as you wish.

Look for comment lines starting with TODO. These are are important
places where most of your code will be added.

