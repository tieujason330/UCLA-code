Jason Tieu
304047667

I was able to complete the assignment, but not all of my results looked exactly like the result template files.
I had an extremely hard time debugging, so in the end I felt I could not fix all the issues that resulted in 
slightly different results.