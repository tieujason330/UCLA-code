This video is a sample of the expected results for Assignment 1.
The two video files show two different points of view.
The animation in the video runs slowly; you may make it run faster.

